﻿namespace com.faithstudio.SDK
{

//#if UNITY_IOS

using UnityEngine;

public class FirebaseAnalyticsEventController : MonoBehaviour {

	/* 
	-----------------------------------------------
	The following class will contain all he firebase event for game specefic
	-----------------------------------------------
	*/

	public static FirebaseAnalyticsEventController Instance;

	void Awake () {
		if (Instance == null) {

			Instance = this;
			DontDestroyOnLoad (gameObject);
		} else {
			Destroy (gameObject);
		}
	}

    //-----------------------------------------------
    #region Public Callback

	public void UpdateGameProgression(string t_ProgressionEventName, int t_ProgressionValue = 1){

		FirebaseAnalyticsEvent t_FirebaseEventForRewardVideoAd = new FirebaseAnalyticsEvent();
        t_FirebaseEventForRewardVideoAd.eventName = "GameProgression";
        t_FirebaseEventForRewardVideoAd.parameter = new FirebaseAnalyticsParameter[1];
        t_FirebaseEventForRewardVideoAd.parameter[0].parameterName = t_ProgressionEventName;
        t_FirebaseEventForRewardVideoAd.parameter[0].parameterValue = t_ProgressionValue;

        FirebaseAnalyticsManager.Instance.UpdateFirebaseEvent(t_FirebaseEventForRewardVideoAd);
	}

    public void UpdateFirebaseEventForRewardVideoAdOnBoost(string t_Purpose)
    {

        FirebaseAnalyticsEvent t_FirebaseEventForRewardVideoAd = new FirebaseAnalyticsEvent();
        t_FirebaseEventForRewardVideoAd.eventName = "AdsMonetization";
        t_FirebaseEventForRewardVideoAd.parameter = new FirebaseAnalyticsParameter[1];
        t_FirebaseEventForRewardVideoAd.parameter[0].parameterName = "RewardVideoAd_" + t_Purpose;
        t_FirebaseEventForRewardVideoAd.parameter[0].parameterValue = 1;

        FirebaseAnalyticsManager.Instance.UpdateFirebaseEvent(t_FirebaseEventForRewardVideoAd);
    }

    #endregion

}

//#endif

}