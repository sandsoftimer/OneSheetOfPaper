﻿namespace com.faithstudio.SDK
{
//#if UNITY_IOS

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public struct FirebaseAnalyticsParameter {
	public string parameterName;
	public float parameterValue;
}

[System.Serializable]
public struct FirebaseAnalyticsEvent {
	public string eventName;
	public FirebaseAnalyticsParameter[] parameter;
}

public class FirebaseAnalyticsManager : MonoBehaviour {

	public static FirebaseAnalyticsManager Instance;
	public static Firebase.FirebaseApp FirebaseAppDefaultInstance;

    #region Private Variables

	private bool m_IsFirebaseIntitialized;

    #endregion

    #region Mono Behaviour

	void Awake () {

		if (Instance == null) {

			
			Instance = this;
			DontDestroyOnLoad (gameObject);
		} else {
			Destroy (gameObject);
		}
	}

    private void Start()
    {
        InitializeFirebase();
    }

    #endregion

    //------------------------------------------------------------
    #region Configuretion	

    private void InitializeFirebase () {

		m_IsFirebaseIntitialized = false;

		Firebase.FirebaseApp.CheckAndFixDependenciesAsync ().ContinueWith (task => {
			var dependencyStatus = task.Result;
			if (dependencyStatus == Firebase.DependencyStatus.Available) {
				// Create and hold a reference to your FirebaseApp, i.e.
				//   app = Firebase.FirebaseApp.DefaultInstance;
				// where app is a Firebase.FirebaseApp property of your application class.
				// Set a flag here indicating that Firebase is ready to use by your
				// application.

				FirebaseAppDefaultInstance = Firebase.FirebaseApp.DefaultInstance;
				m_IsFirebaseIntitialized = true;
				Debug.Log ("Firebase - Intitialized");

			} else {
				UnityEngine.Debug.LogError (System.String.Format (
					"Could not resolve all Firebase dependencies: {0}", dependencyStatus));
				// Firebase Unity SDK is not safe to use here.
			}
		});
	}

    #endregion

	//----------------------------------------
    #region Public Callback

	public bool IsFirebaseReadyToUse () {

		return m_IsFirebaseIntitialized;
	}

	public void UpdateFirebaseEvent (FirebaseAnalyticsEvent t_FirebaseAnalyticsEvent) {

		string eventName = t_FirebaseAnalyticsEvent.eventName;

		int t_NumberOfParameter = t_FirebaseAnalyticsEvent.parameter.Length;
		for (int parameterIndex = 0; parameterIndex < t_NumberOfParameter; parameterIndex++) {
			Firebase.Analytics.FirebaseAnalytics.LogEvent (
				eventName,
				t_FirebaseAnalyticsEvent.parameter[parameterIndex].parameterName,
				t_FirebaseAnalyticsEvent.parameter[parameterIndex].parameterValue
			);
		}
	}

    #endregion
}

//#endif

}


