﻿namespace com.faithstudio.SDK
{
    using System.Collections;
    using UnityEngine;
    using UnityEngine.Advertisements;
    using UnityEngine.Events;

    public class UnityAdsController : MonoBehaviour
    {

        #region PUBLIC VARIABLES

        public static UnityAdsController Instance;

        [Header("RewardVideoAds Property")]
        public bool enableRewardVideoAds;
        public bool rewardedVideoAdsSkipCallback;
        public bool rewardedVideoAdsFailedCallBack;

        public UnityEvent OnRewardVideoAdsFinished;
        public UnityEvent OnRewardVideoAdsSkipped;
        public UnityEvent OnRewardVideoAdsFailed;

        [Header("VideoAds Property")]
        public bool enableVideoAds;
        public bool videoAdsSkipCallback;
        public bool videoAdsFailedCallback;

        public UnityEvent OnVideoAdsFinished;
        public UnityEvent OnVideoAdsSkipped;
        public UnityEvent OnVideoAdsFailed;

        //--------------------------------
        public bool unityTestMode;
        public bool testModeGUI;

        public string gameID;
        public string gameID_Android;
        public string gameID_iOS;

        #endregion

        #region PRIVATE VARIABLES

        private bool mCustomCall;

        private UnityAction OnAdsFinished;
        private UnityAction OnAdsSkipped;
        private UnityAction OnAdsFailed;

        #endregion

        void Awake()
        {

            mPreProcess();
        }

        #region Pre-Process/Process/Post-Process

        void OnGUI()
        {

            if (testModeGUI)
            {

                float width = 0;
                float height = 0;

                if (Screen.width > Screen.height)
                {
                    //Landscape
                    width = Screen.width / 3;
                    height = Screen.height / 16;

                }
                else
                {
                    //Portrait
                    width = Screen.width / 2;
                    height = Screen.height / 12;
                }

                if (Advertisement.isSupported)
                {

                    GUI.TextField(new Rect(0, 0, width, height),
                        "Unity Ads Supported");
                }

                if (GUI.Button(new Rect(0, height, width, height),
                        "Show Ads"))
                {

                    ShowAds();
                }

                if (Advertisement.IsReady("rewardedVideo"))
                {

                    GUI.TextField(new Rect(width, 0, width, height),
                        "rewardVideo (Ready)");
                }
                else
                {

                    GUI.TextField(new Rect(width, 0, width, height),
                        "rewardVideo\n(NOT! Ready)");
                }

                if (Advertisement.IsReady("video"))
                {

                    GUI.TextField(new Rect(width, height, width, height),
                        "video (Ready)");
                }
                else
                {

                    GUI.TextField(new Rect(width, height, width, height),
                        "video (NOT! Ready)");
                }

                if (GUI.Button(new Rect(0, height * 2, width, height),
                        "Show Ads\n(RwVAds)"))
                {

                    ShowRewardVideoAds();
                }

                if (GUI.Button(new Rect(width, height * 2, width, height),
                        "Show Ads\n(VAds)"))
                {

                    ShowVideoAds();
                }

                if (GUI.Button(new Rect(0, height * 3, width * 2, height),
                        "Show Ads\n(BannerAds)"))
                {

                    ShowBannerAd();
                }
            }
        }

        private void mPreProcess()
        {

            mCustomCall = false; ;

            mResetCustomAdsCallBack();

            if (Instance == null)
            {

                Instance = this;
                DontDestroyOnLoad(Instance.gameObject);
            }
            else if (Instance != this)
            {

                Destroy(this.gameObject);
            }




        }

        private void mResetCustomAdsCallBack()
        {

            OnAdsFinished = null;
            OnAdsSkipped = null;
            OnAdsFailed = null;
        }

        #endregion

        //-----------------------------------------------------------------------------
        #region Public Callback

        public void InitializedUnityAds()
        {

            InitializedUnityAds(false, false);
        }

        public void InitializedUnityAds(bool t_IsTestMode)
        {

            InitializedUnityAds(false, true);
        }

        public void InitializedUnityAds(bool t_ForceInitilization, bool t_IsTestMode)
        {

            if (t_ForceInitilization || (Advertisement.isSupported && !IsUnityAdsInitialized()))
            {

#if UNITY_ANDROID

                gameID = gameID_Android;

#elif UNITY_IOS

		gameID = gameID_iOS;

#endif

                Advertisement.Initialize(gameID, t_IsTestMode);
                Debug.Log("UnityAdsLog | " + "Unity Ads Initialized");


            }

        }

        public bool IsUnityAdsInitialized()
        {

            return Advertisement.isInitialized;
        }

        #endregion

        //-----------------------------------------------------------------------------

        #region RewardedVide Ads

        public bool IsRewardedVideoAdsReady()
        {

            if (Advertisement.IsReady("rewardedVideo"))
                return true;
            else
                return false;
        }

        public void ShowRewardVideoAds()
        {

            if (Advertisement.IsReady("rewardedVideo"))
            {

                Advertisement.Show("rewardedVideo", new ShowOptions()
                {

                    resultCallback = HandleRewardAdResult
                });
            }
        }

        public void ShowRewardedVideoAdsWithEvent(UnityAction OnAdsFinished)
        {

            mResetCustomAdsCallBack();

            this.OnAdsFinished = OnAdsFinished;
            mCustomCall = true;

            ShowRewardVideoAds();
        }

        public void ShowRewardedVideoAdsWithEvent(UnityAction OnAdsFinished, UnityAction OnAdsFailed)
        {

            mResetCustomAdsCallBack();

            this.OnAdsFinished = OnAdsFinished;
            this.OnAdsFailed = OnAdsFailed;
            mCustomCall = true;

            ShowRewardVideoAds();
        }

        public void ShowRewardedVideoAdsWithEvent(UnityAction OnAdsFinished, UnityAction OnAdsSkipped, UnityAction OnAdsFailed)
        {

            mResetCustomAdsCallBack();

            this.OnAdsFinished = OnAdsFinished;
            this.OnAdsSkipped = OnAdsSkipped;
            this.OnAdsFailed = OnAdsFailed;
            mCustomCall = true;

            ShowRewardVideoAds();
        }

        private void HandleRewardAdResult(ShowResult result)
        {

            switch (result)
            {

                case ShowResult.Failed:
                    if (mCustomCall)
                    {

                        if (OnAdsFailed != null)
                            OnAdsFailed.Invoke();

                        mCustomCall = false;
                    }
                    else
                    {

                        OnRewardVideoAdsFailed.Invoke();
                    }
                    //Debug.Log ("Failed To Load The RewardAds");
                    break;
                case ShowResult.Skipped:
                    if (mCustomCall)
                    {

                        if (OnAdsSkipped != null)
                            OnAdsSkipped.Invoke();

                        mCustomCall = false;
                    }
                    else
                    {

                        OnRewardVideoAdsSkipped.Invoke();
                    }
                    //Debug.Log ("Skip RewardAds");
                    break;
                case ShowResult.Finished:
                    if (mCustomCall)
                    {

                        if (OnAdsFinished != null)
                            OnAdsFinished.Invoke();

                        mCustomCall = false;
                    }
                    else
                    {

                        OnRewardVideoAdsFinished.Invoke();
                    }
                    //Debug.Log ("Finished RewardAds");
                    break;
            }
        }

        #endregion

        //-----------------------------------------------------------------------------

        #region VideoAds

        public bool IsVideoAdsReady()
        {

            if (Advertisement.IsReady("rewardedVideo"))
                return true;
            else
                return false;
        }

        public void ShowVideoAds()
        {

            if (Advertisement.IsReady("video"))
            {

                Advertisement.Show("video", new ShowOptions()
                {

                    resultCallback = HandleVideoAdResult
                });
            }
        }

        public void ShowVideoAdsWithEvent(UnityAction OnAdsFinished)
        {

            mResetCustomAdsCallBack();

            this.OnAdsFinished = OnAdsFinished;
            mCustomCall = true;

            ShowVideoAds();
        }

        public void ShowVideoAdsWithEvent(UnityAction OnAdsFinished, UnityAction OnAdsFailed)
        {

            mResetCustomAdsCallBack();

            this.OnAdsFinished = OnAdsFinished;
            this.OnAdsFailed = OnAdsFailed;
            mCustomCall = true;

            ShowVideoAds();
        }

        public void ShowVideoAdsWithEvent(UnityAction OnAdsFinished, UnityAction OnAdsSkipped, UnityAction OnAdsFailed)
        {

            mResetCustomAdsCallBack();

            this.OnAdsFinished = OnAdsFinished;
            this.OnAdsSkipped = OnAdsSkipped;
            this.OnAdsFailed = OnAdsFailed;
            mCustomCall = true;

            ShowVideoAds();
        }

        private void HandleVideoAdResult(ShowResult result)
        {

            switch (result)
            {

                case ShowResult.Failed:
                    if (mCustomCall)
                    {

                        if (OnAdsFailed != null)
                            OnAdsFailed.Invoke();

                        mCustomCall = false;
                    }
                    else
                    {

                        OnVideoAdsFailed.Invoke();
                    }
                    //Debug.Log ("Failed To Load The VideoAds");
                    break;
                case ShowResult.Skipped:
                    if (mCustomCall)
                    {

                        if (OnAdsSkipped != null)
                            OnAdsSkipped.Invoke();

                        mCustomCall = false;
                    }
                    else
                    {

                        OnVideoAdsSkipped.Invoke();
                    }
                    //Debug.Log ("Skip VideoAds");
                    break;
                case ShowResult.Finished:
                    if (mCustomCall)
                    {

                        if (OnAdsFinished != null)
                            OnAdsFinished.Invoke();

                        mCustomCall = false;
                    }
                    else
                    {

                        OnVideoAdsFinished.Invoke();
                    }
                    //Debug.Log ("Finished VideoAds");
                    break;
            }
        }

        #endregion

        //-----------------------------------------------------------------------------

        #region BannerAd

        private bool m_IsBannerAdControllerRunning;

        public bool IsBannerAdReady()
        {
            if (Advertisement.IsReady("bannerad"))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool IsBannerAdLoaded()
        {
            if (Advertisement.Banner.isLoaded)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public void ShowBannerAd()
        {

            if (!m_IsBannerAdControllerRunning)
            {

                m_IsBannerAdControllerRunning = true;
                StartCoroutine(ShowBannerAdWhenReady());
            }
        }

        public void HideBannerAd()
        {
            m_IsBannerAdControllerRunning = false;
            Advertisement.Banner.Hide(true);
        }

        public void DestroyBannerAd()
        {
            m_IsBannerAdControllerRunning = false;
            Advertisement.Banner.Hide(false);
        }

        private IEnumerator ShowBannerAdWhenReady()
        {

            BannerLoadOptions t_BannerLoadOption = new BannerLoadOptions();
            t_BannerLoadOption.loadCallback += OnBannerAdSucessfullyLoaded;
            t_BannerLoadOption.errorCallback += ((string errorMessage) => {
                Debug.LogError("UnityAdsLog | " + "Failed to load bannerAd : " + errorMessage);
            });

            WaitForSeconds t_CycleDelay = new WaitForSeconds(5.0f);

            while (m_IsBannerAdControllerRunning)
            {

                if (IsBannerAdReady() && IsBannerAdLoaded())
                {
                    Advertisement.Banner.Show("bannerad");
                    break;
                }
                else
                {
                    Advertisement.Banner.Load("bannerad", t_BannerLoadOption);
                }

                yield return t_CycleDelay;
            }

            StopCoroutine(ShowBannerAdWhenReady());
        }

        private void OnBannerAdSucessfullyLoaded()
        {

            m_IsBannerAdControllerRunning = false;
            Advertisement.Banner.Show("bannerad");
        }

        #endregion

        //-----------------------------------------------------------------------------

        #region ShowAds (With Priority of Rewarded Video Ads -> Video Ads)

        public bool IsAdsReady()
        {

            if (Advertisement.IsReady())
                return true;
            else
                return false;
        }

        public void ShowAds()
        {

            if (Advertisement.IsReady("rewardedVideo"))
            {

                Advertisement.Show("rewardedVideo", new ShowOptions()
                {

                    resultCallback = HandleRewardAdResult
                });
            }
            else if (Advertisement.IsReady("video"))
            {

                Advertisement.Show("video", new ShowOptions()
                {

                    resultCallback = HandleVideoAdResult
                });
            }
        }

        public void ShowAdsWithEvent(UnityAction OnAdsFinished)
        {

            mResetCustomAdsCallBack();
            this.OnAdsFinished = OnAdsFinished;
            ShowAds();
        }

        public void ShowAdsWithEvent(UnityAction OnAdsFinished, UnityAction OnAdsFailed)
        {

            mResetCustomAdsCallBack();
            this.OnAdsFinished = OnAdsFinished;
            this.OnAdsFailed = OnAdsFailed;
            ShowAds();
        }

        public void ShowAdsWithEvent(UnityAction OnAdsFinished, UnityAction OnAdsSkipped, UnityAction OnAdsFailed)
        {

            mResetCustomAdsCallBack();
            this.OnAdsFinished = OnAdsFinished;
            this.OnAdsSkipped = OnAdsSkipped;
            this.OnAdsFailed = OnAdsFailed;
            ShowAds();
        }

        #endregion
    }
}

