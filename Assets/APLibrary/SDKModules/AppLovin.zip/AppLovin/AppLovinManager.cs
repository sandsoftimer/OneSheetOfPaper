﻿namespace com.faithstudio.SDK
{

	using UnityEngine;
	using UnityEngine.Events;

    using System.Collections;

    using com.faithstudio.GameplayService;

	public class AppLovinManager : MonoBehaviour
	{
		#region Public Variables

		public static AppLovinManager Instance;

		public string devKey;

        #endregion

        #region  Private Variables

		private UnityAction OnAdFinished;

		#endregion

		#region Mono Behaviour

		private void Awake()
		{
			if (Instance == null)
			{

				Instance = this;
				DontDestroyOnLoad(gameObject);
			}
			else
			{

				Destroy(gameObject);
			}


		}

        #endregion

        #region Configuretion

        private void InvokeOnSuccessfulAdShowEvent()
        {

            if (OnAdFinished != null)
                OnAdFinished.Invoke();
        }

        private void PreLoadInterstitial()
		{

			NetworkReachabilityController.Instance.AddNetworkReachableEvent(
					delegate {
						AppLovin.PreloadInterstitial();
					},
                    true,
                    true
				);
		}

		private void PreLoadRewardedInterstitial()
		{

			NetworkReachabilityController.Instance.AddNetworkReachableEvent(
				delegate {
					AppLovin.LoadRewardedInterstitial();
				},
                true,
                true
			);
		}

        private IEnumerator PreLoadInterstitialWithDelay() {

            yield return new WaitForSeconds(5);

            PreLoadInterstitial();

            StopCoroutine(PreLoadInterstitialWithDelay());
        }

        private IEnumerator PreLoadRewardedInterstitialWithDelay()
        {

            yield return new WaitForSeconds(5);

            PreLoadRewardedInterstitial();

            StopCoroutine(PreLoadRewardedInterstitialWithDelay());
        }

        void onAppLovinEventReceived(string ev)
		{

            #region AdType  :   Banner
            if (ev.Contains("LOADEDBANNER"))
            {
                //The SDK successfully loaded a banner in the background.

                Debug.LogWarning("AppLovin (BannerAd)   :   LoadedSuccessfully");
            }
            else if (ev.Contains("LOADBANNERFAILED")) {

                //The SDK failed to load a banner.

                Debug.LogWarning("AppLovin (BannerAd)   :   LoadedFailed");

            }else if (ev.Contains("DISPLAYEDBANNER")) {

                //A banner was displayed to the user.

                Debug.LogWarning("AppLovin (BannerAd)   :   Displaying");

            }else if (ev.Contains("DISPLAYFAILED")){

                //The banner has failed to display.

                Debug.LogWarning("AppLovin (BannerAd)   :   DisplayingFailed");

            } else if (ev.Contains("HIDDENBANNER")) {

                //A banner was hidden from view.

                Debug.LogWarning("AppLovin (BannerAd)   :   Hiding");

            }else if (ev.Contains("OPENEDFULLSCREEN")){

                //The banner presented fullscreen content.

                Debug.LogWarning("AppLovin (BannerAd)   :   OpenedFullScreenAd");

                Time.timeScale = 0.0f;
                AudioListener.pause = true;

            }
            else if (ev.Contains("CLOSEDFULLSCREEN")){

                //The fullscreen content of the banner is dismissed.

                Debug.LogWarning("AppLovin (BannerAd)   :   ClosedFullScreenAd");

                Time.timeScale = 1.0f;
                AudioListener.pause = false;

            }
            else if (ev.Contains("LEFTAPPLICATION")){

                //The user is taken out of the application after a click.

                Debug.LogWarning("AppLovin (BannerAd)   :   LeftApplicationFromBannerAd");

            }
            
            #endregion

            #region AdType  :   Interstitial

            if (ev.Contains("LOADEDINTER"))
            {
                //The SDK successfully loaded an interstitial in the background.

                Debug.LogWarning("AppLovin (Interstitial)   :   LoadedSuccessfully");
            }
            else if (ev.Contains("LOADINTERFAILED"))
            {
                //The SDK failed to load a rewarded video.

                Debug.LogWarning("AppLovin (Interstitial)   :   LoadedFailed");

            }else if (ev.Contains("DISPLAYEDINTER")){
                //An interstitial was displayed to the user.

                Debug.LogWarning("AppLovin (Interstitial)   :   Displaying");

            }
            else if (ev.Contains("HIDDENINTER"))
            {
                //An interstitial was closed or hidden from view. If you are preloading interstitials, this is a good place to put a call to PreloadInterstitial

                Debug.LogWarning("AppLovin (Interstitial)   :   Hiding");

                Time.timeScale = 1.0f;
                AudioListener.pause = false;

                PreLoadInterstitial();
            }

            #endregion

            #region AdType  :   RewardedAd

            if (ev.Contains("LOADEDREWARDED"))
            {
                //The SDK successfully loaded a rewarded video in the background.

                Debug.LogWarning("AppLovin (RewardedAd)   :   LoadedSuccessfully");
            }
            else if (ev.Contains("LOADREWARDEDFAILED"))
            {
                //The SDK failed to load a rewarded video.

                Debug.LogWarning("AppLovin (RewardedAd)   :   LoadedFailed");

            }else if (ev.Contains("DISPLAYEDREWARDED"))
            {
                //A rewarded video was displayed to the user.

                Debug.LogWarning("AppLovin (RewardedAd)   :   Displaying");

            }
            else if (ev.Contains("HIDDENREWARDED"))
            {
                //A rewarded video was closed or hidden from view. This would be triggered after the landing screen is closed.

                Debug.LogWarning("AppLovin (RewardedAd)   :   Hiding");

                Time.timeScale = 1.0f;
                AudioListener.pause = false;

                InvokeOnSuccessfulAdShowEvent();

                PreLoadRewardedInterstitial();
            }

            #endregion

            #region AdEvent :   General

            if (ev.Contains("VIDEOBEGAN"))
            {
                //A video ad has begun to play. This is a good opportunity to pause your game and any media assets that are currently playing.

                Debug.LogWarning("AppLovin (VideoAd/RewardedAd)   :   VideoBegin");

                Time.timeScale = 0.0f;
                AudioListener.pause = true;
            }
            else if (ev.Contains("VIDEOSTOPPED")) {

                //A video ad has stopped playing. This is a good opportunity to resume your game and any media assets.

                Debug.LogWarning("AppLovin (VideoAd/RewardedAd)   :   VideoStopped");

            }
            else if (ev.Contains("CLICKED"))
            {
                // An ad was clicked by the user. This means the user will be leaving your application soon.

                Debug.LogWarning("AppLovin (VideoAd/RewardedAd/BannerAd)   :   Clicked");
            }

            #endregion

            #region AdEvent :   Reward

            if (ev.Contains("REWARDAPPROVED"))
            {
                //The AppLovin servers have validated the user's reward.

                Debug.LogWarning("AppLovin (RewardState)   :   Approved");

            }
            else if (ev.Contains("REWARDREJECTED")){

                //The AppLovin servers have rejected the user's reward. This user is most likely fraudulent.

                Debug.LogWarning("AppLovin (RewardState)   :   Rejected due to user fraud");

            }
            else if (ev.Contains("REWARDTIMEOUT")){

                //The AppLovin servers could not be reached.

                Debug.LogWarning("AppLovin (RewardState)   :   Server Timedout");

            }
            else if (ev.Contains("USERCLOSEDEARLY")){

                //The user has closed the ad before reaching the end of playback. You may wish to cancel a previously granted reward since REWARDAPPROVED might be received before USERCLOSEDEARLY.

                Debug.LogWarning("AppLovin (RewardState)   :   Closed Early");

                Time.timeScale = 1.0f;
                AudioListener.pause = false;
            }
            else if (ev.Contains("REWARDAPPROVEDINFO")){

                //This event is sent along with REWARDAPPROVED and contains the amount and name of the currency. The format is

                Debug.LogWarning("AppLovin (RewardState)   :   RewardInfo");

            }

            #endregion

        }


		#endregion

		#region Public Callback

		public void InitializeAppLovin(bool t_TestMode)
		{

			AppLovin.SetSdkKey(devKey);
			AppLovin.InitializeSdk();

			if (t_TestMode)
				AppLovin.SetTestAdsEnabled("true");

			AppLovin.SetUnityAdListener(gameObject.name);

			PreLoadRewardedInterstitial();
		}

        public bool IsInterstitialReady()
        {

            if (AppLovin.HasPreloadedInterstitial())
                return true;

            return false;
        }

        public bool IsRewardedInterstitialReady()
		{

			if (AppLovin.IsIncentInterstitialReady())
				return true;
			
			
	        return false;
			
		}

        public void ShowInterstitialAd(UnityAction OnAdFinished) {

            if (IsInterstitialReady())
            {

                this.OnAdFinished = OnAdFinished;
                AppLovin.ShowInterstitial();
            }
            else {

                this.OnAdFinished = null;
                PreLoadInterstitial();
            }
        }


        public void ShowRewardInterstitialAd(UnityAction OnAdFinished)
		{

			if (IsRewardedInterstitialReady())
			{

				this.OnAdFinished = OnAdFinished;
				AppLovin.ShowRewardedInterstitial();
			}
			else
			{

				this.OnAdFinished = null;
				PreLoadRewardedInterstitial();
			}
		}

        public void ShowBannerAd() {

            NetworkReachabilityController.Instance.AddNetworkReachableEvent(
                    delegate
                    {
                        AppLovin.ShowAd(AppLovin.AD_POSITION_CENTER, AppLovin.AD_POSITION_BOTTOM);
                    },
                    true,
                    true
                );

            
        }

		#endregion

	}
}



